import json
import boto3
import time
from ses_send_email import ses_send_email
from pinpoint_send_email import pinpoint_send_email
from botocore.exceptions import ClientError
import datetime

cloudwatch = boto3.client('cloudwatch')
client = boto3.client('sqs')

def lambda_handler(event, context):
    
    for record in event['Records']:
        print(record)
        json_message = json.loads(record['body'])

        try:
            start_timer = time.perf_counter()
            ses_send_email(json_message)
            stop_timer = time.perf_counter()
            time_to_send_email = stop_timer-start_timer
            
            record_time_to_send = cloudwatch.put_metric_data(
                MetricData = [
                    {
                        'MetricName': 'message_sent_ms',
                        'Unit': 'Milliseconds',
                        'Value': time_to_send_email
                    },
                ],
                Namespace='ses_custom_metrics'
            )
            
            record_no_messages_processed = cloudwatch.put_metric_data(
                MetricData = [
                    {
                        'MetricName': 'no_SQSmessages_processed',
                        'Unit': 'Count',
                        'Value': 1
                    },
                ],
                Namespace='ses_custom_metrics'
            )  
        except Exception as e:
            print("ERROR: ",e)
        
        #If your email throughput is lower than 10 then you should use the sleep function so that the total AWS Lambda function duration is 1 second. Note that when the AWS Lambda function and Amazon Pinpoint are in the same AWS region, the average Amazon Pinpoint API call time is less than 100 milliseconds 
        #time.sleep(0.3)
        
    print("Number of messages processed: " + str(len(event['Records'])))

