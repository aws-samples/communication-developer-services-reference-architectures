import os
import json
import boto3
import time
from botocore.exceptions import ClientError
from botocore.config import Config

config = Config(
   retries = {
      'max_attempts': 0,
      'mode': 'standard'
   }
)

sqs_client = boto3.client('sqs')
pinpoint_client = boto3.client('pinpoint', config=config)
cloudwatch = boto3.client('cloudwatch')
sqs_url = os.environ['SQS_QUEUE_URL']

def pinpoint_send_email(message):

    #APPID = os.environ['APP_ID']
    CHARSET = "UTF-8"

    try:
        pinpoint_email_send = pinpoint_client.send_messages(
            ApplicationId=APPID,
            MessageRequest={
                'Addresses': {
                    message['to']: {
                        'ChannelType': 'EMAIL'
                    }},
                    'MessageConfiguration': {
                        'EmailMessage': {
                            'FromAddress': message['from'],
                            'SimpleEmail': {
                                'Subject': {
                                    'Charset': CHARSET,
                                    'Data': message['subject']
                                },
                                'HtmlPart': {
                                    'Charset': CHARSET,
                                    'Data': message['body-html']
                                },
                                'TextPart': {
                                    'Charset': CHARSET,
                                    'Data': message['body-text']
                                }
                            }
                        }
                    }
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
        error_message = e.response['Error']['Message']
        if error_message == "Maximum sending rate exceeded.":
            cloudwatch.put_metric_data(
                MetricData = [
                    {
                        'MetricName': 'pinpoint_throttling',
                        'Unit': 'Count',
                        'Value': 1
                    },
                ],
                Namespace='pinpoint_custom_metrics'
            ) 
            
            write_back_to_sqs = sqs_client.send_message(
              QueueUrl=sqs_url,
              MessageBody= json.dumps(json_message)
            )
            print("Message back to the queue: " + str(write_back_to_sqs))
        else:
            json_message['error_message'] = e.response['Error']['Message']
            write_back_to_sqs = sqs_client.send_message(
                QueueUrl=sqs_dlq_url,
                MessageBody= json.dumps(json_message)
            )
            print("Unknown error write to DLQ")      
        
    else:
        print("Email sent")