import os
import json
import boto3
import time
from botocore.exceptions import ClientError
from botocore.config import Config

config = Config(
   retries = {
      'max_attempts': 0,
      'mode': 'standard'
   }
)

sqs_client = boto3.client('sqs')
ses_client = boto3.client('ses', config=config)
cloudwatch = boto3.client('cloudwatch')
sqs_url = os.environ['SQS_QUEUE_URL']
sqs_dlq_url = os.environ['SQS_DLQ_QUEUE_URL']

def ses_send_email(json_message):
  CHARSET = "UTF-8"

    # Send the email via SES
  try:
    email_send = ses_client.send_email(
        Destination={
            'ToAddresses': [
                json_message['to'],
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': json_message['body-html'],
                },
                'Text': {
                    'Charset': CHARSET,
                    'Data': json_message['body-text'],
                },
            },
            'Subject': {
                'Charset': CHARSET,
                'Data': json_message['subject'],
            },
        },
        Source=json_message['from']
    )
  except ClientError as e:
    print(e.response['Error']['Message'])
    error_message = e.response['Error']['Message']
    if error_message == "Maximum sending rate exceeded.":
      cloudwatch.put_metric_data(
          MetricData = [
              {
                  'MetricName': 'ses_throttling',
                  'Unit': 'Count',
                  'Value': 1
              },
          ],
          Namespace='ses_custom_metrics'
      ) 
      
      write_back_to_sqs = sqs_client.send_message(
        QueueUrl=sqs_url,
        MessageBody= json.dumps(json_message)
      )
      print("Message back to the queue: " + str(write_back_to_sqs))
    else:
        json_message['error_message'] = e.response['Error']['Message']
        write_back_to_sqs = sqs_client.send_message(
              QueueUrl=sqs_dlq_url,
              MessageBody= json.dumps(json_message)
            )
        print("Unknown error write to DLQ")
  else:
    print("Email sent")