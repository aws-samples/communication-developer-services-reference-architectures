const AWS = require('aws-sdk');
AWS.config.update({
    region: process.env.Region
});

const {
    recognizeText
} = require("./LexAPI");

const {
    sendSms
} = require("./PinPointAPI");

exports.handler = async (event) => {
    
    console.log(JSON.stringify(event, null,2));
    console.log('Received event: ' + event.Records[0].Sns.Message);
    var message = JSON.parse(event.Records[0].Sns.Message);
    
    var lexResponse = await recognizeText(message.originationNumber.substr(2), message.messageBody); 
    console.log(lexResponse);
    
    if(lexResponse.messages && lexResponse.messages[0].content){
        const messageId = await sendSms(message.originationNumber, lexResponse.messages[0].content);
    } else {
        console.error("Unknown Response from Lex");
    }
};
