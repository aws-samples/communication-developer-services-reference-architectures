const AWS = require('aws-sdk');
AWS.config.update({
  region: "us-east-1"
});

const pinpoint = new AWS.Pinpoint();
const originationNumber = process.env.OriginationNumber;
const PINPOINT_APPLICATION_ID = process.env.PinpointApplicationId;
const messageType = "TRANSACTIONAL";

async function sendSms(destinationNumber, messageBody) {
    console.log("Send SMS to customer via Pinpoint.");
    const pinpointSendMessageParams = {
      ApplicationId: PINPOINT_APPLICATION_ID,
      MessageRequest: {
        Addresses: {
          [destinationNumber]: {
            ChannelType: 'SMS'
          }
        },
        MessageConfiguration: {
          SMSMessage: {
            Body: messageBody,
            MessageType: messageType,
            OriginationNumber: originationNumber
          }
        }
      }
    };
    console.log(`Body: ${messageBody} Number : ${destinationNumber}`);
    
    const data = await pinpoint.sendMessages(pinpointSendMessageParams).promise();
    console.log("Message sent! " 
        + data['MessageResponse']['Result'][destinationNumber]['MessageId']);
    return data['MessageResponse']['Result'][destinationNumber]['MessageId'];
}

module.exports = {
    sendSms
};