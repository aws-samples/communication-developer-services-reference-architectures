import json
import boto3
import os

client = boto3.client('sqs')

sqs_url = os.environ['SQS_QUEUE_URL']
no_of_messages = int(os.environ['NO_OF_MESSAGES'])

def lambda_handler(event, context):
    
    # Constructing a JSON object with email related fields and send it to SQS
    """
    messages = event['messages']
    for message in messages:
        message_to_send = {
            "from": message['from'],
            "to": message['to'],
            "subject":message['subject'],
            "body-html": message['body-html'],
            "body-text": message['body-text']
        }
        message_to_send = json.dumps(message_to_send)
        
        message_to_sqs = client.send_message(
            QueueUrl= sqs_url,
            MessageBody= message_to_send
        )
        print(message_to_sqs)
    """

    # Dummy messages to SQS for testing purposes. Assuming each message is one email
    message_counter = 0
    while message_counter < no_of_messages:
        
        message_to_send = {
            "from": os.environ["EMAIL_FROM"],
            "to": "success@simulator.amazonses.com",
            "subject": "Hello from AWS",
            "body-html": f"""<html> <head></head> <body> <h1>Hello from AWS</h1> </body> </html> """ ,
            "body-text": "Hello from AWS"
        }
        message_to_send = json.dumps(message_to_send)
    
        dummy_message_to_sqs = client.send_message(
            QueueUrl= sqs_url,
            MessageBody= message_to_send
        )
        print(dummy_message_to_sqs)
        
        message_counter = message_counter + 1